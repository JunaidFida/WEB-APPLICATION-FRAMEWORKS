const express = require('express');
const router = express.Router();
const cricketController = require('../controllers/cricketController');

// Home page route
router.get('/', cricketController.homepage);

// Scoreboard route
router.get('/scoreboard', cricketController.scoreboard);

// Series info route
router.get('/series', cricketController.seriesInfo);

// Teams route
router.get('/teams', cricketController.teams);

// Player details route
router.get('/player/:id', cricketController.playerDetails);

// Search player route
router.get('/searchPlayer', (req, res) => {
    res.render('searchPlayer');
});
router.post('/searchPlayer', cricketController.searchPlayer);

module.exports = router;
