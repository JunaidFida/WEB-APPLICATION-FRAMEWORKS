const cricketDataService = require('../services/cricketDataService');
const Player = require('../models/player');
const Team = require('../models/team');
const Series = require('../models/series');

// Homepage
exports.homepage = async (req, res) => {
    try {
        // Fetch recent series data
        const series = await cricketDataService.getSeriesInfo();
        
console.log(series);  // Log the response to inspect its structure

// Continue with your existing logic...

        
        // Check if the series data is available
        if (!series || series.length === 0) {
            return res.render('index', { series: [], message: 'No series data available.' });
        }

        res.render('index', { series });
    } catch (error) {
        res.status(500).send(error.message);
    }
};


// Scoreboard
exports.scoreboard = async (req, res) => {
    try {
        // Fetch recent match data
        const matches = await cricketDataService.getRecentMatches();
        res.render('scoreboard', { matches });
    } catch (error) {
        res.status(500).send(error.message);
    }
};

// Series Info
exports.seriesInfo = async (req, res) => {
    try {
        // Fetch planned series data
        const series = await cricketDataService.getSeriesInfo();
        res.render('series', { series });
    } catch (error) {
        res.status(500).send(error.message);
    }
};

// Teams
exports.teams = async (req, res) => {
    try {
        // Fetch teams data (such as ICC Men’s T20 World Cup teams)
        const teams = await cricketDataService.getTeamDetails();
        res.render('teams', { teams });
    } catch (error) {
        res.status(500).send(error.message);
    }
};

// Player Details
exports.playerDetails = async (req, res) => {
    try {
        const playerId = req.params.id;  // Get the player ID from the URL parameter
        const player = await cricketDataService.getPlayerDetails(playerId);
        res.render('player', { player });
    } catch (error) {
        res.status(500).send(error.message);
    }
};

// Search Player
exports.searchPlayer = async (req, res) => {
    try {
        const playerName = req.body.name;  // Get the player name from the form input
        const players = await Player.find({ name: new RegExp(playerName, 'i') });  // Search in the database
        
        if (players.length > 0) {
            res.render('player', { player: players[0] });
        } else {
            res.render('searchPlayer', { message: 'Player not found' });
        }
    } catch (error) {
        res.status(500).send(error.message);
    }
};
