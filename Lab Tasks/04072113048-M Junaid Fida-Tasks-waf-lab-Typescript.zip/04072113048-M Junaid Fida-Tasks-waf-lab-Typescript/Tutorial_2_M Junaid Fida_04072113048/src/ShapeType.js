"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ShapeType = void 0;
// src/ShapeType.ts
var ShapeType;
(function (ShapeType) {
    ShapeType["Circle"] = "CIRCLE";
    ShapeType["Rectangle"] = "RECTANGLE";
})(ShapeType || (exports.ShapeType = ShapeType = {}));
